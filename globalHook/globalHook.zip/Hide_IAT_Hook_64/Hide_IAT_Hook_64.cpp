﻿// Hide_IAT_Hook_64.cpp : DLL을 위해 내보낸 함수를 정의합니다.
//

#include "pch.h"
#include "framework.h"
#include "Hide_IAT_Hook_64.h"


// 내보낸 변수의 예제입니다.
HIDEIATHOOK64_API int nHideIATHook64=0;

// 내보낸 함수의 예제입니다.
HIDEIATHOOK64_API int fnHideIATHook64(void)
{
    return 0;
}

// 내보낸 클래스의 생성자입니다.
CHideIATHook64::CHideIATHook64()
{
    return;
}
